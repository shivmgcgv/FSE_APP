package com.companyservice.company.repository;

import com.companyservice.company.entity.Company;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyRepository extends MongoRepository<Company, String> {

    Company findByCode(String companyCode);

    //List<Stock> findAllByDateLessThanEqualAndDateGreaterThanEqual(String startDate, String endDate);
    //List<Stock> findAllByDateGreaterThanEqualAndDateLessThanEqualAndCompanyCode(String startDate, String endDate, String companycode);
    //List<Stock> findAllByDateLessThanEqualAndCompanyCode(String endDate, String companycode);
    //List<Stock> findAllByDateGreaterThanEqualAndDateLessThanEqual(String startDate, String endDate);
    //List<Stock> getAllBetweenDate(String startDate, String endDate);
}