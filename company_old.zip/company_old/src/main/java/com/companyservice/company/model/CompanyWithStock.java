package com.companyservice.company.model;

import com.companyservice.company.entity.Company;
import lombok.Data;

import java.util.List;

@Data
public class CompanyWithStock {

    private Company company;

    private List<Stock> stocks;
}