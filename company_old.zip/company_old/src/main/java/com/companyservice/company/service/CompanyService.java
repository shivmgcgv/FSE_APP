package com.companyservice.company.service;

import com.companyservice.company.entity.Company;
import com.companyservice.company.model.CompanyWithStock;
import com.companyservice.company.model.Stock;
import com.companyservice.company.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class CompanyService {

    public static final String stockBaseURL = "http://localhost:8082/stockmarket/api/v1.0/market/stock";

    @Autowired
    CompanyRepository repository;

    RestTemplate restTemplate = new RestTemplate();

    public Company registerNewCompany(Company company) {
        Company oldCompany = fetchesCompanyDetails(company.getCode());
        if (ObjectUtils.isEmpty(oldCompany))
            return repository.save(company);
        else
            throw new RuntimeException("Company with given code is already exists");
    }

    public Company fetchesCompanyDetails(String companycode) {
        return repository.findByCode(companycode);
    }

    public List<Company> findAllCompany(){
        return repository.findAll();
    }

    public boolean deleteCompany(String companycode) {

        Company company = fetchesCompanyDetails(companycode);
        if (!ObjectUtils.isEmpty(company)){
            restTemplate.delete(stockBaseURL+"/delete/"+companycode,companycode);
            repository.delete(company);
        }
        else
            throw new RuntimeException("Invalid Company code");
        return true;
    }

    public CompanyWithStock getCompanyInfoWithStockByCompanyCode(String companycode) {

        CompanyWithStock companyWithStock = new CompanyWithStock();
        Company company = fetchesCompanyDetails(companycode);
        if (!ObjectUtils.isEmpty(company)){
            List<Stock> stocks = (List<Stock>) restTemplate.getForObject(stockBaseURL+"/get/"+companycode, Object.class);
            companyWithStock.setCompany(company);
            companyWithStock.setStocks(stocks);
        }
        return companyWithStock;
    }
}
