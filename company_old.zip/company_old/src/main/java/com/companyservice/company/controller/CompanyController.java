package com.companyservice.company.controller;

import com.companyservice.company.entity.Company;
import com.companyservice.company.model.CompanyWithStock;
import com.companyservice.company.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/stockmarket/api/v1.0/market/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    /*'
     Register a new company
	 To Access from Zuul API Gateway
	 http://localhost:8989/stockmarket/api/v1.0/market/company/register
    */
    @PostMapping("/register")
    public Company registerNewCompany(@RequestBody Company company) {
        return companyService.registerNewCompany(company);
    }

    /*
     Fetches the Company  Details
	 To Access from Zuul API Gateway
	 http://localhost:8989/stockmarket/api/v1.0/market/company/register
    */
    @GetMapping("/info/{companycode}")
    public Company fetchesCompanyDetails(@PathVariable(name = "companycode") String companycode) {
        return companyService.fetchesCompanyDetails(companycode);
    }

    @GetMapping("/")
    public String hello()  {
        return "Hello from Company Service...";
    }

    /*
     Fetches all the Company Details
	 To Access from Zuul API Gateway
	 http://localhost:8989/stockmarket/api/v1.0/market/company/register
    */
    @GetMapping("/getall")
    public List<Company> fetchesAllCompanyDetails() {
        return companyService.findAllCompany();
    }

    /*
     Deletes a company
	 To Access from Zuul API Gateway
	 http://localhost:8989/stockmarket/api/v1.0/market/company/register
    */
    @DeleteMapping("/delete/{companycode}")
    public Boolean deleteCompanyByCompanyCode(@PathVariable(name = "companycode") String companycode) {
        Boolean isDeleted = companyService.deleteCompany(companycode);
        return isDeleted;
    }

    @GetMapping("/infowithstock/{companycode}")
    public CompanyWithStock getCompanyInfoWithStockByCompanyCode(@PathVariable(name = "companycode") String companycode) {
        return companyService.getCompanyInfoWithStockByCompanyCode(companycode);
    }
}

