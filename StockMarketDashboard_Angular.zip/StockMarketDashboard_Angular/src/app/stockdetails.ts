export class StockDetail {
    id: string;
    companycode: string;
    stockprice: number;
    createdDate: string;
    createdTime: string;
}