import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { CompanyDetails } from '../companydetails';

@Component({
  selector: 'app-companydetails',
  templateUrl: './companydetails.component.html',
  styleUrls: ['./companydetails.component.css']
})
export class CompanydetailsComponent implements OnInit {

  companyDetail: CompanyDetails;
  companyDetailsArray:CompanyDetails[];
  isDeleted:boolean;
  constructor(private companyService: CompanyService) { }

  ngOnInit(): void {
   this.refreshCompanies();
  }

  refreshCompanies() {
    this.companyService.fetchesAllCompanyDetails()
      .subscribe(data => {
        console.log(data)
        this.companyDetailsArray=data;
      })      
  }

  async deleteCompany(companyCode:CompanyDetails){

    this.companyService.deleteCompanyByCompanyCode(companyCode.code).subscribe(data =>
    {
        alert("Deleted Successfully...");
        this.ngOnInit();
    },
    error1 =>
    {
         alert("Not deleted... Please try again after some time...");
    });
  }
}
