import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyComponent } from './company/company.component';
import { StockComponent } from './stock/stock.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CompanydetailsComponent } from './companydetails/companydetails.component';
import { StockdetailsComponent } from './stockdetails/stockdetails.component';
import { CompanysearchComponent } from './companysearch/companysearch.component';

const routes: Routes = [

  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'company', component: CompanyComponent },
  { path: 'searchCompany', component: CompanysearchComponent },
  { path: 'listOfCompanies', component: CompanydetailsComponent },
  { path: 'addStocks', component: StockComponent },
  { path: 'listAllStocks', component: StockdetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
