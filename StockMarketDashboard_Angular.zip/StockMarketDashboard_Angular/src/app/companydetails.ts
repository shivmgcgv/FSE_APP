export class CompanyDetails {
    id: number;
    code: string;
    name: string;
    ceo: string;
    turnover: string;
    website: string;
    stockExchange: string;
}