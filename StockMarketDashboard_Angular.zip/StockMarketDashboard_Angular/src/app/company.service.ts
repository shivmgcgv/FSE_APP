import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CompanyDetails } from './companydetails';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    Authorization: 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})

export class CompanyService {

  private baseUrl = 'http://localhost:8081/stockmarket/api/v1.0/market/company';

  constructor(private http: HttpClient) { }
  errorMessage:any;

  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
      alert("Request unsuccessful.." + error.error.message); 
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
        alert("Request unsuccessful.." + error.error.message); 
    }
    // Return an observable with a user-facing error message.
    return throwError(
      'Something bad happened; please try again later.');
  }

  registerNewCompany(company: Object): Observable<Object>{

    return this.http.post(`${this.baseUrl}`, company);
  }

  /** POST: add a new Company to the database */
  addNewCompany(company: CompanyDetails): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(company);
    console.log(body)
    return this.http.post(this.baseUrl + '/register', body,{'headers':headers})
    .pipe(catchError(this.handleError));
}

async create(company: CompanyDetails): Promise<any> {
  const headers = { 'content-type': 'application/json'} 
  const body=JSON.stringify(company); 
  try {
    return await this.http
      .post(this.baseUrl + '/register', body,{'headers':headers})
      .toPromise();
    //return res;
  } catch (error) {
    await this.handleError(error);
  }
}

addNewCompany2() {
  this.http.post<any>(this.baseUrl+"/register", { title: 'Angular POST Request Example' }).subscribe({
      next: data => {
         // this.postId = data.id;
      },
      error: error => {
          this.errorMessage = error.message;
          console.error('There was an error!', error);
      }
  })
}

  fetchesCompanyDetails(companyCode: string): Observable<any>{

    return this.http.get(this.baseUrl+'/info/'+companyCode);
  }

  fetchesAllCompanyDetails(): Observable<any>{

    return this.http.get(this.baseUrl+'/getall');
  }

  deleteCompanyByCompanyCode(companyCode: string): Observable<any>{

    return this.http.delete(this.baseUrl+'/delete/'+companyCode, { responseType: 'text' });
  }

  getCompanyWithStock(companyCode: string): Observable<any>{

    return this.http.get(this.baseUrl+'/infowithstock/'+companyCode);
  }

}
