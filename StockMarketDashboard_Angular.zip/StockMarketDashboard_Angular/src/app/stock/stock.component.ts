import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { CompanyDetails } from '../companydetails';
import { CompanyWithStocks } from '../companywithstocks';
import { StockService } from '../stock.service';
import { StockDetail } from '../stockdetails';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {

  companyDetails =new CompanyDetails();
  companyCode : string;
  displayElement: boolean;
  listOfStock: StockDetail[];
  stockDetail = new StockDetail();
  date: any;
  listOfStocks: StockDetail[];
  listOfCompanies: CompanyDetails[];
  stockprice :number;
  selectedValue: string;
  mySelect: string;
  companyWithStocks = new CompanyWithStocks();
  
  constructor(private stockService: StockService, private companyService: CompanyService) { }

  ngOnInit(): void {
    this.refreshCompanies();
   }
 
   refreshCompanies() {
     this.companyService.fetchesAllCompanyDetails()
       .subscribe(data => {
         console.log(data)
         this.listOfCompanies=data;
       })      
   }
 
  applyDateFilter(){
    
  }
  
  addNewStock(){
    this.stockDetail.companycode = this.companyCode;
    this.stockDetail.createdDate = this.date;
    this.stockDetail.stockprice = this.stockprice;
    console.log(this.stockDetail);
    this.onClickSubmit();
  }

  highlightRow(selectedCode: string){
    console.log("Selected Company Code : "+selectedCode);
    this.companyCode = selectedCode;
  }

  async onClickSubmit() {
    this.stockService.addNewStock(this.stockDetail).subscribe(
      data=>
      {
        alert("Added Successfully...");
      },
      error1 =>
      {
         alert("Not Added Please try again...");
      }
  )
 }

}
