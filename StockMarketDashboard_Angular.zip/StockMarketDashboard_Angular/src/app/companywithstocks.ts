import { CompanyDetails } from "./companydetails";
import { StockDetail } from "./stockdetails";

export class CompanyWithStocks {
    company: CompanyDetails;
	stocks: StockDetail[];
}