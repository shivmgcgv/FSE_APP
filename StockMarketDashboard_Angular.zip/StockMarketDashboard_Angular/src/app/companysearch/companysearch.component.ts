import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { CompanyDetails } from '../companydetails';
import { CompanyWithStocks } from '../companywithstocks';
import { StockService } from '../stock.service';
import { StockDetail } from '../stockdetails';

@Component({
  selector: 'app-companysearch',
  templateUrl: './companysearch.component.html',
  styleUrls: ['./companysearch.component.css']
})
export class CompanysearchComponent implements OnInit {

  companyDetails=new CompanyDetails();
  companyCode : string ='';
  displayElement: boolean;
  listOfStock: StockDetail[];
  tempListOfStock: StockDetail[];
  fromdate: any;
  todate: any;
  max :number;
  min :number;
  avg :number;
  companyWithStocks = new CompanyWithStocks();
  listOfCompanies: CompanyDetails[];
  constructor(private stockService: StockService, private companyService: CompanyService) { }

  ngOnInit(): void {
    this.refreshCompanies();
   }
 
   refreshCompanies() {
     this.companyService.fetchesAllCompanyDetails()
       .subscribe(data => {
         console.log(data)
         this.listOfCompanies=data;
       })      
   }

   highlightRow(selectedCode: string){
    console.log("Selected Company Code : "+selectedCode);
    this.companyCode = selectedCode;
  }

  getCompanyDetail(code: string) {
    this.companyCode = code;
    this.companyDetails=new CompanyDetails();
    this.companyWithStocks = new CompanyWithStocks();
    this.displayElement = false;
    if(this.companyCode.trim() !=''){ 
    this.companyService.fetchesCompanyDetails(this.companyCode)
      .subscribe(data => {
        console.log(data)
        this.companyWithStocks=data;
        if(null != this.companyWithStocks && this.companyWithStocks.company.code!="") {
          this.companyDetails = this.companyWithStocks.company;
          this.listOfStock = this.companyWithStocks.stocks;
          this.tempListOfStock = this.companyWithStocks.stocks;
          this.displayElement = true;
          this.companyCode='';
          //this.max = Math.max(this.listOfStock.forEach(a=>this.listOfStock));
        }
        else alert("Company with code "+this.companyCode+" not found...");
      })      
  }else alert("Enter Company Code to search company details...");
}

getCompanyWithStockDetails(code: string) {
  this.companyCode = code;
  this.companyWithStocks =new CompanyWithStocks();
  this.displayElement = false;
  if(this.companyCode.trim() !=''){ 
  this.companyService.getCompanyWithStock(this.companyCode)
    .subscribe(data => {
      console.log(data)
      this.companyWithStocks = data;
      console.log("this.companyWithStocks  :"+this.companyWithStocks)
      if(null !== data && this.companyWithStocks.company!=null) {
        this.displayElement = true;
        this.companyCode='';
        this.listOfStock = this.companyWithStocks.stocks;
      }
      else alert("Company with code "+this.companyCode+" not found...");
    })      
}else alert("Enter Company Code to search company details...");
}

applyDateFilter(startDate: any, endDate: any){
  console.log(" S D :"+ startDate +"  ED :"+endDate);
  this.tempListOfStock = this.companyWithStocks.stocks;
  var result = this.tempListOfStock.filter((stock: StockDetail) =>{
    return stock.createdDate >= startDate && stock.createdDate <= endDate;
  });
  this.listOfStock = result;
  console.log(this.listOfStock);
}

clearDateFilter(){
  this.fromdate = null;
  this.todate = null;
  this.listOfStock = this.companyWithStocks.stocks;
  console.log(this.listOfStock);
}

}
