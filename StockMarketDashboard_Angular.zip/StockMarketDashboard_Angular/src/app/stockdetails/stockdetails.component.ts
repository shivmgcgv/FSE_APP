import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { StockService } from '../stock.service';
import { StockDetail } from '../stockdetails';

@Component({
  selector: 'app-stockdetails',
  templateUrl: './stockdetails.component.html',
  styleUrls: ['./stockdetails.component.css']
})
export class StockdetailsComponent implements OnInit {

  StockDetails:any= [];

  constructor(private stockService: StockService) { }

  ngOnInit() {
    this.stockService.getAllStockDetails().subscribe((res: any[])=>{
      this.StockDetails=res;
    })
  }
  
  async deleteStock(stock: StockDetail)
  {
        this.stockService.deleteStockById(stock.id).subscribe(data=>
          {
            alert("Deleted Successfully...");
            this.ngOnInit();
          },
          error1 =>
          {
             alert("Not deleted... Please try again after some time...");
          });
  }
}