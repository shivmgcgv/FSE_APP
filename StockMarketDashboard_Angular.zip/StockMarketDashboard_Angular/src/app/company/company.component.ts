import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CompanyService } from '../company.service';
import { CompanyDetails } from '../companydetails';
//import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  todaydate: any;
  companyDetails: CompanyDetails;
  formdata: any;
  companyDetailsArray:CompanyDetails[];
  constructor(private companyService: CompanyService) { }

  ngOnInit(): void {
   
  }

  /*
  refreshCompanies() {
    this.companyService.fetchesAllCompanyDetails()
      .subscribe(data => {
        console.log(data)
        this.companyDetailsArray=data;
      })      
  }
  */

  async onClickSubmit(formData: NgForm) {
    this.companyService.addNewCompany(formData.value).subscribe(
      data=>
      {
        alert("Added Successfully...");
        //this.refreshCompanies();
        formData.reset();
      },
      error1 =>
      {
         alert("Not Added Please try again...");
      }
  )
 }

 async onClickSubmit2(companyToAdd: CompanyDetails): Promise<void> {
  const code = companyToAdd.code.trim();
  if (!code) { return; }
  let company = await this.companyService.create(companyToAdd);
  this.companyDetailsArray.push(company);
  companyToAdd = new CompanyDetails();
}

 onClickSubmit3(companyDetails: any) {
 this.companyService
  .addNewCompany(companyDetails)
  .subscribe(companyDetails => this.companyDetailsArray.push(companyDetails));
}


// newCompanyDetails(newCompanyDetails: any) {
//  throw new Error('Function not implemented.');
//}
}

