import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CompanyComponent } from './company/company.component';
import { StockComponent } from './stock/stock.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CompanydetailsComponent } from './companydetails/companydetails.component';
import { StockdetailsComponent } from './stockdetails/stockdetails.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CompanysearchComponent } from './companysearch/companysearch.component';

@NgModule({
  declarations: [
    AppComponent,
    CompanyComponent,
    StockComponent,
    HomeComponent,
    AboutComponent,
    DashboardComponent,
    CompanydetailsComponent,
    StockdetailsComponent,
    CompanysearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    BrowserAnimationsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
