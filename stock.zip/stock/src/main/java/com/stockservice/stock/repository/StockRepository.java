package com.stockservice.stock.repository;

import com.stockservice.stock.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface StockRepository extends JpaRepository<Stock, Long> {

    @Query("select s from Stock s where s.companycode=:companycode AND s.createddate Between :startDate AND :endDate")
    List<Stock> findStockBtwGivenDate(
            @Param("companycode") String companycode,
            @Param("startDate") String startDate,
            @Param("endDate") String endDate);

    List<Stock> findByCompanycode(String code);

    @Transactional
    void deleteByCompanycode(String code);

    @Transactional
    void deleteById(Long id);
}