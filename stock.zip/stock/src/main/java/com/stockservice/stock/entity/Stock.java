package com.stockservice.stock.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "stocks")
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String stockprice;
    private String companycode;
    private String createddate;
    private String createdtime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStockprice() {
        return stockprice;
    }

    public void setStockprice(String stockprice) {
        this.stockprice = stockprice;
    }

    public String getCompanycode() {
        return companycode;
    }

    public void setCompanycode(String companycode) {
        this.companycode = companycode;
    }

    public String getCreatedDate() {
        return createddate;
    }

    public void setCreatedDate(String createdDate) {
        this.createddate = createdDate;
    }

    public String getCreatedTime() {
        return createdtime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdtime = createdTime;
    }
}