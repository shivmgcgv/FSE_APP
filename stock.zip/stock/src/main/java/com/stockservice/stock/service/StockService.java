package com.stockservice.stock.service;

import com.stockservice.stock.entity.Stock;
import com.stockservice.stock.repository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
public class StockService {

    @Autowired
    StockRepository stockRepository;

    public List<Stock> getByCompanyCode(String companycode) {
        return stockRepository.findByCompanycode(companycode);
    }

    public List<Stock> findStockBtwGivenDate(String startdate, String enddate, String companycode) {
        return stockRepository.findStockBtwGivenDate(companycode, startdate, enddate);
    }

    public List<Stock> getAllStocks() {
        return stockRepository.findAll();
    }

    public void deleteByCompanycode(String companyCode) {
        stockRepository.deleteByCompanycode(companyCode);
    }

    public void deleteById(Long id) {
        stockRepository.deleteById(id);
    }

    public Stock addNewStock(Stock stock) {
        if(null != stock.getCompanycode() && null != stock.getStockprice())
            return stockRepository.save(stock);
        else
            throw new RuntimeException("Bad Request...");
    }
}
