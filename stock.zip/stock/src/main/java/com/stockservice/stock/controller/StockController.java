package com.stockservice.stock.controller;

import com.stockservice.stock.entity.Stock;
import com.stockservice.stock.service.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/stockmarket/api/v1.0/market/stock")
public class StockController {

    @Autowired
    StockService stockService;

    @PostMapping("/savestock")
    public Stock addNewStock(@RequestBody Stock stock) {
        if(null == stock.getCreatedDate()) {
            stock.setCreatedDate(String.valueOf(LocalDate.now()));
        }
        stock.setCreatedTime(String.valueOf(LocalTime.now()));
        return stockService.addNewStock(stock);
    }

    @GetMapping("/getall")
    public List<Stock> getAll() {
        List<Stock> stock1 = stockService.getAllStocks();
        return stock1;
    }

    @GetMapping("/get/{companycode}")
    public List<Stock> getByCompanyCode(@PathVariable String companycode) {
        return stockService.getByCompanyCode(companycode);
    }

    @DeleteMapping("/delete/{companycode}")
    public boolean deleteStockByCompanyCode(@PathVariable String companycode) {
        try {
            stockService.deleteByCompanycode(companycode);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @DeleteMapping("/deleteById/{id}")
    public boolean deleteStockById(@PathVariable Long id) {
        try {
            stockService.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @GetMapping("/get/{companycode}/{startdate}/{enddate}")
    public List<Stock> getByCompanyCode(@PathVariable String companycode,
                                        @PathVariable String startdate, @PathVariable String enddate) {
        List<Stock> stock1 = stockService.findStockBtwGivenDate(companycode, startdate, enddate);
        return stock1;
    }
}